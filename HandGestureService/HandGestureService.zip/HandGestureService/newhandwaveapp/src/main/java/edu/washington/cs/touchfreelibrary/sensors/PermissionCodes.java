package edu.washington.cs.touchfreelibrary.sensors;

public class PermissionCodes {
    public static int CAMERAPERMISSIONCODE = 245;
}
